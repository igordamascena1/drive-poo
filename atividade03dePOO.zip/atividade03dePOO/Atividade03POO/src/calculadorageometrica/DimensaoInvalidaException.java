package calculadorageometrica;

public class DimensaoInvalidaException extends Exception {
    public DimensaoInvalidaException(String mensagem) {
        super(mensagem);
    }
}
